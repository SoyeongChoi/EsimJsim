package com.example.chm31.esimjsim;

import android.support.v4.app.Fragment;

public class SafetyFragment extends Fragment {


}